# GloLaunch Product Package

- **SKU**: UDS-MDF-WHT-2PK-001
- **Platform**: Amazon
- **Market**: US
- **Compliance**: ComplianceStatus.FAIL
- **Listing Health**: 66/100 (Grade C)

## Contents

| File | Description |
|------|-------------|
| product.json | Product attributes |
| listing.json | Listing content |
| market-analysis.json | Market insights |
| opportunity-score.json | Opportunity score data |
| health-check.json | Listing health data |
| images/ | Product images (if available) |
